<?php
/**
 * Delta Sync SHA-256 + sanitizado FULLTEXT BOOLEAN MODE (sin WordPress Test Suite).
 */

if (!defined('ABSPATH')) {
    define('ABSPATH', '/tmp/wordpress/');
}
if (!function_exists('apply_filters')) {
    function apply_filters($tag, $value, ...$args) {
        return $value;
    }
}

if (!class_exists('Xabia_Knowledge_Sync', false)) {
    class Xabia_Knowledge_Sync {
        public static function is_mec_catalog_config(array $config): bool {
            return ($config['sql_preset'] ?? '') === 'mec_remote';
        }

        public static function is_remote_config(array $config): bool {
            return ($config['source_type'] ?? '') === 'sql'
                && trim((string) (($config['sql_config']['host'] ?? ''))) !== '';
        }
    }
}

require_once dirname(__DIR__) . '/core/class-xabia-knowledge-optimizer.php';
require_once dirname(__DIR__) . '/core/class-xabia-db.php';
require_once dirname(__DIR__) . '/core/class-xabia-brain.php';

$chunk = "Club Hípico Castillo\n";
$trim = trim($chunk);
$sha = hash('sha256', $trim);
$md5_raw = md5($chunk);
$md5_trim = md5($trim);

assert(strlen($sha) === 64, 'sha256 hex length is 64');
assert(Xabia_Knowledge_Optimizer::content_hash($chunk) === $sha, 'optimizer uses sha256(trim)');
assert(Xabia_Knowledge_Optimizer::content_hash($chunk) !== $md5_raw, 'optimizer no longer uses md5');
assert(Xabia_DB::compute_content_hash($chunk) === $sha, 'db compute_content_hash delegates to optimizer');
assert(Xabia_DB::content_hash_matches($sha, $chunk), 'sha256 matches');
assert(Xabia_DB::content_hash_matches($md5_raw, $chunk), 'legacy md5(raw) still matches');
assert(Xabia_DB::content_hash_matches($md5_trim, $chunk), 'legacy md5(trim) still matches');
assert(!Xabia_DB::content_hash_matches($sha, $trim . ' changed'), 'different text does not match');

$q = Xabia_Brain::build_fulltext_boolean_query('excursiones a caballo +"DROP TABLE"', ['excursiones', 'caballo']);
assert(strpos($q, '"') === false, 'boolean query strips quotes');
assert(strpos($q, '+excursiones*') !== false, 'boolean query requires excursiones prefix');
assert(strpos($q, '+caballo*') !== false, 'boolean query requires caballo prefix');
assert(strpos($q, 'excursionesacaballo') === false, 'compound phrase is not glued into one FT token');
assert(!preg_match('/(?<![A-Za-z])a\*/', $q), 'two-letter tokens are omitted');

$ops = Xabia_Brain::build_fulltext_boolean_query('++foo --bar ~baz @user (x)', []);
assert(strpos($ops, '+foo*') !== false, 'foo kept after stripping operators');
assert(strpos($ops, '--') === false, 'boolean minus operators stripped');
assert(strpos($ops, '~') === false, 'tilde operator stripped');
assert(strpos($ops, '@') === false, 'against @ operator stripped');

$empty = Xabia_Brain::build_fulltext_boolean_query('sí no', []);
assert($empty === '', 'short tokens yield empty boolean query (LIKE fallback)');

$bebe = Xabia_Brain::build_fulltext_boolean_query('cuando actúa bebé', []);
assert(strpos($bebe, 'bebe') !== false, 'unaccent keeps bebe entity');
assert(strpos($bebe, 'actua') === false, 'action verb actua is a stop-word');
assert(strpos($bebe, 'cuando') === false, 'cuando is a stop-word');
assert($bebe === '+bebe*' || strpos($bebe, '+bebe*') !== false, 'boolean query focuses on bebe');

$refl = new ReflectionClass('Xabia_Brain');
$like_m = $refl->getMethod('normalize_search_like_terms');
$like_m->setAccessible(true);
$like_terms = $like_m->invoke(null, 'cuando actúa bebé');
assert(in_array('bebe', $like_terms, true), 'LIKE terms include unaccented bebe');
assert(in_array('bebé', $like_terms, true), 'LIKE terms keep accented bebé variant');

$catalog_sql = 'SELECT p.ID FROM wp_posts p WHERE p.post_type = \'catalog_item\'';
$local_filtered = Xabia_Knowledge_Optimizer::apply_incremental_sql_filter(
    $catalog_sql,
    'demo-agent',
    ['source_type' => 'local_sql']
);
assert($local_filtered === $catalog_sql, 'local WP catalog does not filter by post_modified');

echo "OK test-xabia-delta-sync.php\n";
