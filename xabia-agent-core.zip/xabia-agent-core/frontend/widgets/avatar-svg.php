<?php
/**
 * Avatar cinético Xabia (SVG compartido: trigger flotante + modo inmersivo).
 */
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Path de boca: silueta exacta del asset de diseño (techo plano + cuenco).
 *
 * @return string
 */
function xabia_avatar_mouth_path_d(): string {
	return 'M263.43,250.5 C254.36,250.67 249.02,251.19 245.39,251.53 C241.76,251.87 242.9,252.04 241.65,252.55 C240.4,253.06 238.87,253.93 237.9,254.61 C236.94,255.3 236.65,255.46 235.86,256.66 C235.07,257.86 233.65,260.09 233.14,261.8 C232.63,263.51 232.69,265.22 232.8,266.93 C232.91,268.64 233.37,270.52 233.82,272.06 C234.27,273.6 234.44,274.29 235.52,276.17 C236.6,278.05 239.04,281.65 240.29,283.36 C241.54,285.07 241.25,284.9 243.01,286.44 C244.77,287.98 248.28,290.89 250.83,292.6 C253.38,294.31 256.16,295.68 258.32,296.71 C260.48,297.74 261.44,298.07 263.77,298.76 C266.09,299.44 269.89,300.36 272.27,300.82 C274.65,301.28 275.79,301.39 278.06,301.5 C280.33,301.61 282.82,301.78 285.88,301.5 C288.94,301.22 293.59,300.42 296.43,299.79 C299.27,299.16 300.4,298.76 302.9,297.73 C305.39,296.7 309.02,295.0 311.4,293.63 C313.78,292.26 315.49,290.89 317.19,289.52 C318.89,288.15 320.19,286.95 321.61,285.41 C323.03,283.87 324.56,281.99 325.7,280.28 C326.83,278.57 327.63,277.02 328.42,275.14 C329.21,273.26 330.06,270.86 330.46,268.98 C330.86,267.1 330.97,265.56 330.8,263.85 C330.63,262.14 330.06,260.08 329.44,258.71 C328.82,257.34 327.97,256.49 327.06,255.63 C326.15,254.78 325.52,254.26 323.99,253.58 C322.46,252.9 321.9,252.04 317.87,251.53 C313.84,251.02 308.9,250.67 299.83,250.5 C290.76,250.33 272.5,250.33 263.43,250.5 Z';
}

/**
 * Boca “pensando”: misma silueta, ya escalada y ladeada en coordenadas SVG
 * (sin transform CSS/SVG que el navegador pueda malinterpretar).
 *
 * @return string
 */
function xabia_avatar_thinking_mouth_path_d(): string {
	return 'M271.43,267.83 C267.79,268.95 265.69,269.78 264.27,270.34 C262.84,270.89 263.32,270.83 262.88,271.18 C262.43,271.53 261.91,272.06 261.6,272.45 C261.29,272.84 261.19,272.93 261.01,273.51 C260.83,274.09 260.52,275.15 260.51,275.9 C260.5,276.65 260.72,277.33 260.97,278.01 C261.21,278.69 261.61,279.39 261.97,279.96 C262.33,280.53 262.48,280.79 263.14,281.43 C263.79,282.06 265.19,283.23 265.89,283.78 C266.6,284.32 266.46,284.29 267.35,284.71 C268.24,285.12 269.99,285.89 271.22,286.29 C272.45,286.68 273.73,286.91 274.72,287.08 C275.71,287.25 276.14,287.27 277.16,287.28 C278.17,287.28 279.81,287.21 280.83,287.12 C281.84,287.03 282.31,286.95 283.24,286.73 C284.17,286.51 285.2,286.29 286.4,285.82 C287.6,285.36 289.39,284.49 290.46,283.91 C291.53,283.33 291.94,283.04 292.83,282.33 C293.72,281.63 294.99,280.52 295.79,279.69 C296.59,278.86 297.13,278.11 297.65,277.36 C298.18,276.61 298.57,275.98 298.96,275.19 C299.36,274.4 299.76,273.47 300.02,272.65 C300.28,271.82 300.42,271.11 300.52,270.26 C300.62,269.41 300.69,268.34 300.63,267.53 C300.58,266.73 300.44,266.09 300.18,265.42 C299.91,264.75 299.44,263.99 299.03,263.5 C298.62,263.02 298.18,262.78 297.71,262.54 C297.25,262.3 296.93,262.16 296.24,262.06 C295.54,261.97 295.22,261.68 293.53,261.94 C291.84,262.21 289.81,262.64 286.13,263.62 C282.45,264.6 275.07,266.71 271.43,267.83 Z';
}

/**
 * @param array{bg?:string,shadow?:string,dots?:string,mouth?:string} $colors
 * @param array{class?:string,size?:string}                            $args
 */
function xabia_render_kinetic_avatar_svg(array $colors = [], array $args = []): string {
	$bg = esc_attr($colors['bg'] ?? '#99ccff');
	$shadow = esc_attr($colors['shadow'] ?? '#ffffff');
	$dots = esc_attr($colors['dots'] ?? '#ff9966');
	$mouth = esc_attr($colors['mouth'] ?? '#FFFFFF');
	$mouth_d = esc_attr(xabia_avatar_mouth_path_d());
	$think_d = esc_attr(xabia_avatar_thinking_mouth_path_d());
	$extra_class = isset($args['class']) ? sanitize_html_class((string) $args['class']) : '';
	$wrapper_class = trim('xabia-kinetic-wrapper' . ($extra_class !== '' ? ' ' . $extra_class : ''));

	ob_start();
	?>
	<div class="<?php echo esc_attr($wrapper_class); ?>" aria-hidden="true">
		<div class="x-avatar-container">
			<svg class="x-avatar-stage" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 458.59 353.58" focusable="false" aria-hidden="true">
				<g class="x-avatar-head-layer">
					<circle cx="281.8" cy="176.79" r="176.79" class="x-avatar-fill-bg" fill="<?php echo $bg; ?>" />
				</g>
				<g class="x-avatar-sockets-layer">
					<circle cx="317.98" cy="120.11" r="64.58" class="x-avatar-fill-socket" fill="<?php echo $shadow; ?>" />
					<path d="M175.05,91.52c12.83,0,24.11,4.94,32.42,13.4,8.21,8.37,12.99,19.48,12.99,32.01s-4.86,24.04-13.17,32.42c-8.29,8.35-19.5,13.22-32.23,13.22s-23.94-4.87-32.23-13.22c-8.32-8.38-13.17-19.65-13.17-32.42s4.78-23.64,12.99-32c8.31-8.46,19.59-13.4,32.42-13.4h-.02Z" class="x-avatar-fill-socket" fill="<?php echo $shadow; ?>" />
				</g>
				<g class="x-avatar-eyes-layer">
					<g class="x-avatar-eye-wrap x-avatar-eye-wrap-main">
						<circle cx="301.98" cy="126.52" r="66.53" class="x-avatar-fill-dot x-avatar-eye x-avatar-eye-main" fill="<?php echo $dots; ?>" />
					</g>
					<g class="x-avatar-eye-wrap x-avatar-eye-wrap-secondary">
						<path d="M154.73,97.07c13.21,0,24.84,5.09,33.39,13.81,8.46,8.62,13.38,20.07,13.38,32.97s-5.01,24.77-13.57,33.4c-8.54,8.6-20.09,13.62-33.2,13.62s-24.66-5.01-33.2-13.62c-8.57-8.63-13.57-20.24-13.57-33.4s4.93-24.36,13.38-32.97c8.56-8.72,20.18-13.81,33.39-13.81h0Z" class="x-avatar-fill-secondary x-avatar-eye x-avatar-eye-secondary" fill="#ccb3b3" />
					</g>
					<g class="x-avatar-eye-wrap x-avatar-eye-wrap-side">
						<path d="M27.03,188.69c-7.91,0-14.39-2.61-19.44-7.83-5.06-5.22-7.59-11.78-7.59-19.68s2.52-13.99,7.59-19.21c5.05-5.22,11.53-7.82,19.44-7.82s14.38,2.61,19.44,7.82c5.05,5.22,7.59,11.61,7.59,19.21s-2.53,14.46-7.59,19.68c-5.05,5.22-11.54,7.83-19.44,7.83h0Z" class="x-avatar-fill-bg x-avatar-eye x-avatar-eye-side" fill="<?php echo $bg; ?>" />
					</g>
				</g>
				<g class="x-avatar-mouth-layer">
					<path
						class="x-avatar-mouth"
						d="<?php echo $mouth_d; ?>"
						fill="<?php echo $mouth; ?>"
						opacity="0"
					/>
					<path
						class="x-avatar-thinking-smile"
						d="<?php echo $think_d; ?>"
						fill="<?php echo $mouth; ?>"
						opacity="0"
					/>
				</g>
			</svg>
		</div>
	</div>
	<?php
	return (string) ob_get_clean();
}
